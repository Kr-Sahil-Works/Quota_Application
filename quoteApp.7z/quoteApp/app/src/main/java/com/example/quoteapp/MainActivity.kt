package com.example.quoteapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var quoteText: TextView
    private lateinit var authorText: TextView
    private lateinit var refreshButton: Button
    private lateinit var shareButton: Button
    private lateinit var favoriteButton: ImageButton
    private lateinit var favoritesRecyclerView: RecyclerView
    
    private var currentQuote: Quote? = null
    private val favoriteQuotes = mutableListOf<Quote>()
    private val quotes = listOf(
        Quote("The only way to do great work is to love what you do.", "Steve Jobs"),
        Quote("Innovation distinguishes between a leader and a follower.", "Steve Jobs"),
        Quote("Stay hungry, stay foolish.", "Steve Jobs"),
        Quote("Your time is limited, don't waste it living someone else's life.", "Steve Jobs"),
        Quote("The future belongs to those who believe in the beauty of their dreams.", "Eleanor Roosevelt"),
        Quote("Success is not final, failure is not fatal: it is the courage to continue that counts.", "Winston Churchill"),
        Quote("Believe you can and you're halfway there.", "Theodore Roosevelt"),
        Quote("Everything you've ever wanted is on the other side of fear.", "George Addair"),
        Quote("The best way to predict the future is to create it.", "Peter Drucker"),
        Quote("Don't watch the clock; do what it does. Keep going.", "Sam Levenson")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupClickListeners()
        displayRandomQuote()
        setupRecyclerView()
    }

    private fun initializeViews() {
        quoteText = findViewById(R.id.quoteText)
        authorText = findViewById(R.id.authorText)
        refreshButton = findViewById(R.id.refreshButton)
        shareButton = findViewById(R.id.shareButton)
        favoriteButton = findViewById(R.id.favoriteButton)
        favoritesRecyclerView = findViewById(R.id.favoritesRecyclerView)
    }

    private fun setupClickListeners() {
        refreshButton.setOnClickListener {
            displayRandomQuote()
        }

        shareButton.setOnClickListener {
            shareCurrentQuote()
        }

        favoriteButton.setOnClickListener {
            toggleFavorite()
        }
    }

    private fun displayRandomQuote() {
        currentQuote = quotes.random()
        updateQuoteDisplay()
    }

    private fun updateQuoteDisplay() {
        currentQuote?.let { quote ->
            quoteText.text = quote.text
            authorText.text = "- ${quote.author}"
            favoriteButton.setImageResource(
                if (quote.isFavorite) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )
        }
    }

    private fun shareCurrentQuote() {
        currentQuote?.let { quote ->
            val shareText = "${quote.text}\n- ${quote.author}"
            val sendIntent: Intent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, shareText)
                type = "text/plain"
            }
            startActivity(Intent.createChooser(sendIntent, "Share Quote"))
        }
    }

    private fun toggleFavorite() {
        currentQuote?.let { quote ->
            quote.isFavorite = !quote.isFavorite
            if (quote.isFavorite) {
                if (!favoriteQuotes.contains(quote)) {
                    favoriteQuotes.add(quote)
                    Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show()
                }
            } else {
                favoriteQuotes.remove(quote)
                Toast.makeText(this, "Removed from favorites", Toast.LENGTH_SHORT).show()
            }
            updateQuoteDisplay()
            favoritesRecyclerView.adapter?.notifyDataSetChanged()
        }
    }

    private fun setupRecyclerView() {
        favoritesRecyclerView.layoutManager = LinearLayoutManager(this)
        favoritesRecyclerView.adapter = FavoritesAdapter(favoriteQuotes)
    }
} 