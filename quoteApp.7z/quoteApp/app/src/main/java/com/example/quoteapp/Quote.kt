package com.example.quoteapp

data class Quote(
    val text: String,
    val author: String,
    var isFavorite: Boolean = false
) 